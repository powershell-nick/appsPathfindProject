package application.model;

import java.util.ArrayList;
import java.util.ListIterator;

import javafx.collections.ObservableList;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Shape;


/**
 * Model is Java class that sets up our buildings and searching algorithms.<br>
 * It contains methods to create and load up our buildings/obstacles into lists as well as methods relating to our searching algorithm.<br>
 * It also contains ArrayLists for storing all the lines draw on screen as well as x,y coordinates for all the points the algorithm has visited.<br>
 * This class also handles clearing out all lines drawn on screen through the search algorithm.
 * 
 * @author Brent Delia (gis262), Nicholas Calzada (emy990), Samantha Ramos (alk208), Matthew Rodriguez (gjz898)
 * UTSA CS 3443 - Applications Final Project
 * Fall 2019
 */

public class Model {
	
    private ArrayList<Building> buildings = new ArrayList<Building>();
    private ArrayList<Building> obstacles = new ArrayList<Building>();
    private ArrayList<Line> path = new ArrayList<Line>();
    private ArrayList<Double> visitedPoints = new ArrayList<Double>();
    
    /**
     * Method which instantiates and loads up our list of buildings and obstacles. Called only once.
     */
    
    public void loadBuildings() {
    	// Campus buildings
    	buildings.add(new Building("Applied Engineering and Technology Building", 1180.0, 720.0, new Polygon(new double[] {20.0, 41.0, 43.0, 26.0, 5.0, -48.0, -20.0, -31.0}), 1167.0, 717.0, false));
    	buildings.add(new Building("Arts Building", 1230.0, 575.0, new Polygon(new double[] {0.0, 60.0, 27.0, 81.0, 89.0, 50.0, 21.0, -1.0, -22.0, 21.0}), 1196.0, 503.0, false));    	
    	buildings.add(new Building("Bosque Street Building", 940.0, 382.0, new Polygon(new double[] {36.0, 25.0, 79.0, 4.0, 66.0, -19.0, 29.0, 4.0}), 883.0, 366.0, false));    	 
    	buildings.add(new Building("Biosciences Building", 1145.0, 650.0, new Polygon(new double[] {49.0, 36.0, 78.0, 36.0, 57.0, -12.0, 34.0, 2.0}), 1087.0, 631.0, false));
    	buildings.add(new Building("Biotechnology Sciences and Engineering Building", 1210.0, 680.0, new Polygon(new double[] {-4.0, 89.0, 38.0, 68.0, -4.0, -11.0, -44.0, 11.0}), 1218.0, 642.0, true));
    	buildings.add(new Building("Business Building", 1180.0, 385.0, new Polygon(new double[] {25.0, 35.0, 95.0, 0.0, 69.0, -52.0, 1.0, -16.0}), 1125.0, 386.0, false));    	
    	buildings.add(new Building("Convocation Center", 908.0, 614.0, new Polygon(new double[] {-24.0, -32.0, 36.0, -68.0, 18.0, -106.0, -47.0, -75.0}), 912.0, 680.0, false));
    	buildings.add(new Building("Engineering Building", 1178.0, 632.0, new Polygon(new double[] {170.0, 120.0, 210.0, 98.0, 190.0, 67.0, 150.0, 86.0}), 998.0, 529.0, false));
    	buildings.add(new Building("Flawn Sciences Building", 1150.0, 585.0, new Polygon(new double[] {83.0, 78.0, 145.0, 40.0, 117.0, -13.0, 54.0, 24.0}), 1046.0, 541.0, false));
    	buildings.add(new Building("Graduate School & Research Building", 997.0, 320.0, new Polygon(new double[] {93.0, 91.0, 115.0, 81.0, 85.0, 34.0, 108.0, 17.0, 101.0, -4.0, 54.0, 24.0}), 918.0, 273.0, false));
    	buildings.add(new Building("H-E-B Student Union", 1010.0, 562.0, new Polygon(new double[] {8.0, 94.0, 71.0, 58.0, 34.0, -6.0, -30.0, 29.0}), 1005.0, 510.0, false));    	
    	buildings.add(new Building("John Peace Library", 1215.0, 440.0, new Polygon(new double[] {35.0, 34.0, 90.0, 4.0, 62.0, -48.0, 8.0, -19.0}), 1160.0, 440.0, false));   
    	buildings.add(new Building("Intercollegiate Athletics Building", 890.0, 550.0, new Polygon(new double[] {-31.0, 44.0, 23.0, 16.0, 2.0, -21.0, -49.0, 10.0}), 895.0, 535.0, false));
    	buildings.add(new Building("Main Building", 1280.0, 445.0, new Polygon(new double[] {95.0, 82.0, 153.0, 47.0, 123.0, -10.0, 106.0, -2.0, 123.0, 30.0, 79.0, 53.0}), 1171.0, 369.0, false));
    	buildings.add(new Building("McKinney Humanities Building", 1090.0, 445.0, new Polygon(new double[] {17.0, 37.0, 94.0, -10.0, 70.0, -57.0, -6.0, -10.0}), 1046.0, 436.0, false));
    	buildings.add(new Building("Multidisciplinary Studies Building", 1090.0, 525.0, new Polygon(new double[] {17.0, 37.0, 62.0, 11.0, 27.0, -57.0, -20.0, -31.0}), 1070.0, 522.0, false));     	
    	buildings.add(new Building("North Paseo Building", 1052.0, 310.0, new Polygon(new double[] {163.0, 122.0, 186.0, 107.0, 150.0, 39.0, 129.0, 54.0}), 893.0, 220.0, true));   	
    	buildings.add(new Building("Recreation Wellness Center", 808.0, 685.0, new Polygon(new double[] {184.0, 147.0, 227.0, 90.0, 198.0, 3.0, 86.0, 59.0, 93.0, 83.0, 163.0, 147.0}), 625.0, 626.0, false));
    	buildings.add(new Building("Science and Engineering Building", 1270.0, 670.0, new Polygon(new double[] {163.0, 122.0, 206.0, 96.0, 178.0, 43.0, 137.0, 67.0}), 1106.0, 571.0, false));
    	buildings.add(new Building("Student Union", 1000.0, 490.0, new Polygon(new double[] {154.0, 115.0, 260.0, 61.0, 230.0, -6.0, 192.0, 18.0, 137.0, 88.0}), 794.0, 415.0, true));
    	buildings.add(new Building("Thermal Energy Plant", 930.0, 415.0, new Polygon(new double[] {160.0, 112.0, 196.0, 92.0, 186.0, 68.0, 150.0, 86.0}), 756.0, 316.0, false));
   
    	// Obstacles which are initialized as buildings, as our algorithm can incorporate it as if it was a building to maneuver around
    	obstacles.add(new Building("Obstacle", 970.0, 590.0, new Polygon(new double[] {24.0, 95.0, 71.0, 82.0, 32.0, -5.0, -10.0, 20.0}), 944.0, 552.0, false));
    	obstacles.add(new Building("Obstacle", 1090.0, 640.0, new Polygon(new double[] {71.0, 227.0, 136.0, 192.0, 30.0, -4.0, -30.0, 29.0}), 1044.0, 579.0, false));    
    	obstacles.add(new Building("Obstacle", 890.0, 690.0, new Polygon(new double[] {47.0, 176.0, 113.0, 150.0, -16.0, -89.0, -47.0, -75.0}), 882.0, 703.0, false));
    	obstacles.add(new Building("Obstacle", 1070.0, 380.0, new Polygon(new double[] {17.0, 71.0, 83.0, 38.0, 55.0, -15.0, -10.0, 20.0}), 1022.0, 346.0, false));   	
   
    }

    /**
     * Fetches our list of buildings
     * @return The list of buildings
     */ 
    public ArrayList<Building> getBuildingsList() {
    	return buildings;
    }
    
    /**
     * Fetches our list of obstacles
     * @return The list of obstacles
     */
    public ArrayList<Building> getObstacleList() {
    	return obstacles;
    }
    
    /**
     * Searches our list of buildings to find a matching name
     * @param buildingName The name of the building we want to find as a String
     * @return The Building object whose name matches the buildingName String parameter
     */
    public Building findBuilding(String buildingName) {
    	Building found = null;
    	for(Building b : buildings) {
    		if(b.getName().equals(buildingName)) {
    			found = b;
    			break;
    		}
    	}
    	return found;
    }
    
    
    /**
     * A search algorithm from either a starting building to an ending building, or a line point to an ending building<br>
     * This search algorithm will initially draw a straight line path, find all intersected buildings/obstacles, and attempt to maneuver around them.<br>
     * Note that some buildings have a flag which denotes if a line can pass through it, such as the Student Union<br>
     * Also, this function will recursively call itself as each new line is drawn so it tries to move around the closest intersected building/obstacle
     * @param oldLine Previous line segment that was drawn from a previous iteration of this method
     * @param current Current building that our line segment is currently starting at
     * @param end Our end building point
     * @param pane The pane which contains all of our building boundaries and line segments
     * @param storedPoints A matrix of X,Y points that stores points which would overlap a building if we move towards it
     * @param storedPointsIndex The count of X,Y points that are currently being stored in storedPoints
     */
    public void pathfind(Line oldLine, Building current, Building end, Pane pane, double [][] storedPoints, int storedPointsIndex) {
    	
    	// Offsets with our map nodes, to make sure our lines are properly centered below each node
    	final int node_offset_x = 5;
    	final int node_offset_y = 13;
    	
    	// Create a straight line path to determine if any intersections with buildings/walls are found
    	Line line_path = new Line();
    	line_path.setVisible(false);
    	// If this is our first line being drawn: 
    	if(oldLine == null) {
        	line_path.setStartX(current.getX()-node_offset_x);
        	line_path.setStartY(current.getY()-node_offset_y);
    	}
    	// Otherwise, set our starting position to our previous line's end points
    	else {
    		line_path.setStartX(oldLine.getEndX());
    		line_path.setStartY(oldLine.getEndY());
    	}

    	line_path.setEndX(end.getX()-node_offset_x);
    	line_path.setEndY(end.getY()-node_offset_y);
    	pane.getChildren().add(line_path);
    	path.add(line_path);
    	
    	ArrayList<Building> intersectedBuildings = new ArrayList<Building>();
    	
    	// Combine our buildings list with our obstacles list
    	ArrayList<Building> combinedBuildings = new ArrayList<Building>();
    	combinedBuildings.addAll(buildings);
    	combinedBuildings.addAll(obstacles);
    	
    	// Find all intersected buildings (excluding start and end points)
    	for(Building b : combinedBuildings) {
    		if(b == end || (b == current && (oldLine == null || current.canPass()))) continue;

    		Polygon p = b.getBoundary();
    		// Check for intersection
    		Shape shape = Shape.intersect(line_path, p);
    		boolean intersects = shape.getBoundsInLocal().getWidth() >= 0 || shape.getBoundsInLocal().getHeight() >= 0;
    		if(intersects) {
    			intersectedBuildings.add(b);
    		}
    	}
    	// Create our official line path
    	Line line = createLine(pane);
    	
    	// If this is the first line we are drawing: 
    	if(oldLine == null) {	
        	line.setStartX(current.getX()-node_offset_x);
        	line.setStartY(current.getY()-node_offset_y);
    	}
    	// Otherwise, set this line's starting point to our previous line's end points
    	else {
        	line.setStartX(oldLine.getEndX());
        	line.setStartY(oldLine.getEndY());    		
    	}

    	// If there are no intersected buildings/obstacles, go directly to the end building's points
    	if(intersectedBuildings.size() == 0) {
    		line.setEndX(end.getX()-node_offset_x);
    		line.setEndY(end.getY()-node_offset_y);
    	}   
    	
    	else {
    		// Otherwise, find the closest building/obstacle
    		Building closest = null;
    		double distance = Double.MAX_VALUE;
    		double _x = oldLine == null ? current.getX() : oldLine.getEndX();
    		double _y = oldLine == null ? current.getY() : oldLine.getEndY();
    		
    		for(Building b : intersectedBuildings) {
    			double d = Math.sqrt(Math.pow(_x-b.getX(), 2) + Math.pow(_y-b.getY(), 2));
    			if(distance > d) {
    				distance = d;
    				closest = b;
    			}
    		}
    		
    		Polygon boundary = closest.getBoundary();
    		double [] points;
    		
    		// If all the vertices of our current building overlap with our current point, simply get the closest point and allow intersection
    		if((storedPoints != null && storedPointsIndex >= storedPoints.length)) {
    			//System.out.println("No viable points. getting closest");
	    		points = getClosestPoint(line.getStartX(), line.getStartY(), current, end, null);
	        	line.setEndX(points[0]);
	        	line.setEndY(points[1]);
	        	visitedPoints.add(points[0]);
	        	visitedPoints.add(points[1]);
	        	pathfind(line, closest, end, pane, null, 0);
    		}
    		else { 
    			// If the building we are approaching allows us to pass through, then set our line path's end points to that building's X,Y coordinates
    			if(closest.canPass()) {
    				line.setEndX(closest.getX()-node_offset_x);
    				line.setEndY(closest.getY()-node_offset_y);
    				pathfind(line, closest, end, pane, null, 0);
    			}
    			else {
    				// Attempt to find the closest path that we have not tried
    				points = getClosestPoint(line.getStartX(), line.getStartY(), closest, end, storedPoints);
            		line.setEndX(points[0]);
            		line.setEndY(points[1]);
            		
            		//Check for intersection
        		    Shape shape = Shape.intersect(line, boundary);
        	    	boolean intersects = shape.getBoundsInLocal().getWidth() >= 0 || shape.getBoundsInLocal().getHeight() >= 0;
        	    	if(intersects) {
        	    		//System.out.println("intersects");
        	    		// If we have not stored any points, initialize it
        	        	if(storedPoints == null) {
        	        		//System.out.println("Creating");
        	        		storedPoints = new double[boundary.getPoints().size()/2][boundary.getPoints().size()/2];
        	        		// If our current building matches our closest building, add any vertices we traveled on
        	        		if(current.equals(closest)) {
        	        			storedPoints[storedPointsIndex++] = new double[] {oldLine.getEndX(), oldLine.getEndY()};
        	        		}
        	        	}
        	        	storedPoints[storedPointsIndex++] = points;
        	        	// Remove the line and try again with our previous line and current building
        	        	path.remove(line);
        	        	pane.getChildren().remove(line);
        	        	pathfind(oldLine, current, end, pane, storedPoints, storedPointsIndex);
        	    	}
        	    	else {
        	    		// Add the x,y points to our list of visited points and continue on to the next path
        	    		visitedPoints.add(points[0]);
        	    		visitedPoints.add(points[1]);
        	    		//System.out.println("Added visited paths");
        	    		pathfind(line, closest, end, pane, null, 0);
        	    	}
    			}
    		}
    	}
    }

    /**
     * This method instantiates lines based off how we want them to be as we create various lines in different places within our searching algorithm<br>
     * It also adds the line to our path pane and path list
     * @param pane The pane which stores our line paths and building/obstacle boundaries
     * @return A line object created with the desired settings
     */
    public Line createLine(Pane pane) {
    	Line l = new Line();
    	l.setStroke(Color.RED);
    	l.setStrokeWidth(3.0);
    	l.setVisible(true);
    	pane.getChildren().add(l);
    	path.add(l);
    	return l;
    }
    
    /**
     * A method which clears out all lines from our path pane and path list. It also removes all x,y points from our list of visited points
     * @param pane The pane which stores our line paths and building/obstacle boundaries
     */
    public void clearLines(Pane pane) {
    	for(Line l : path) {
    		pane.getChildren().remove(l);
    	}
    	path.clear();
    	visitedPoints.clear();
    }
    
    /**
     * A method which finds the closest vertex of the current building's Polygon boundary, minus the x,y points that are within excludePoints
     * @param lineX The x coordinate of our line's starting point
     * @param lineY The y coordinate of our line's starting point
     * @param current The current building whose Polygon boundary we are trying to traverse around
     * @param end The destination building, which will be a factor if we can not find valid vertices from our line point
     * @param excludePoints A list of x,y coordinates that we do not want to factor in our search
     * @return
     */
    public double [] getClosestPoint(double lineX, double lineY, Building current, Building end, double [][] excludePoints) {
    	Polygon boundary = current.getBoundary();
    	ObservableList<Double> points = boundary.getPoints();
    	
    	double smallest = Double.MAX_VALUE;
    	double [] smallestPos = new double[2];
    	
    	boolean checkAllPoints = false;
    	
    	int displacement = 5; // An offset for our bounding box when finding vertices below
    	int offset = 4; // An offset for our line, depending on where the vertex is in relation to the current building's x,y coordinate
    	
    	// Loop until we have a valid vertex to move on
    	while(smallestPos[0] == 0 && smallestPos[1] == 0) {
    		
    		ListIterator<Double> iterator = points.listIterator();
    		
    		// Find closest distance between line point and boundary points
        	while(iterator.hasNext()) {
        		double x = iterator.next() + boundary.getLayoutX();
        		double y = iterator.next() + boundary.getLayoutY();
        		//System.out.println("checking point: " + x + ", " + y);
        		
        		// Find if our x,y coordinate above is in our excludePoint list
        		boolean foundExcludePoints = false;
        		if(excludePoints != null) {
            		for(int i = 0; i < excludePoints.length; i ++) {
            			//System.out.println(excludePoints[i][0] + " = " + x + "," + excludePoints[i][1] + " = " + y);
            			if((excludePoints[i][0] == x+offset || excludePoints[i][0] == x-offset) && (excludePoints[i][1] == y+offset || excludePoints[i][1] == y-offset)) {
            				//System.out.println("found excluded points");
            				foundExcludePoints = true;
            			}
            		}
        		}
        		if(foundExcludePoints) continue;

        		// Only check points on the boundary polygon that are within the x and y boundaries between the starting point and ending point
        		if(checkAllPoints || !((x > lineX+displacement && x > end.getX()+displacement) || (x < lineX-displacement && x < end.getX()-displacement) || (y > lineY+displacement && y > end.getY()+displacement) || (y < lineY-displacement && y < end.getY()-displacement)))	{	
            		double distance = 0.0;
            		
            		 // Find closest point from our end building point
        			if(checkAllPoints)
        				distance = Math.sqrt(Math.pow(end.getX() - x, 2) + Math.pow(end.getY() - y, 2));
        			// Find closest point from our line coordinate point
        			else 
        				distance = Math.sqrt(Math.pow(lineX - x, 2) + Math.pow(lineY - y, 2));

            		// If we are somewhere around our current point:
            		if(distance <= 10) {
            			continue;
            		}
            		
            		// If this distance is our closest distance
            		if(smallest > distance) {
            			int x_offset = 0;
            			int y_offset = 0;
            			
            			// Set our x,y offsets based off where the vertex coordinate is in relation to the building's x,y coordinate
            			if(x > current.getX()) {
            				x_offset = offset;
            				if(y > current.getY()) {
	            				y_offset = offset;
            				}
            				else {
            					y_offset = -offset;
            				}
            			}
            			else {
            				x_offset = -3;
            				if(y > current.getY()) {
            					y_offset = offset;
            				}
            				else {
            					y_offset = -offset;
            				}
            			}

            			// Offset the point so it's not along the edge/point of the obstacle
            			x += x_offset;
            			y += y_offset;
            			
            			//System.out.println("Current: " + current.getName());
            	    	//System.out.println(x_offset);
            	    	//System.out.println(y_offset);
            			smallest = distance;
            			smallestPos = new double[] {x, y};
            			//System.out.println("smallest: " + x + "," + y);
            		}
        		}
        	}
        	// If we can't find a close point that is within the X,Y bounds of the line point and end point, toggle checkAllPoints to search all points instead
        	if(smallestPos[0] == 0.0 && smallestPos[1] == 0.0) {
        		//System.out.println("checking all points now" + " " + current.getName() + " " + end.getName());
        		checkAllPoints = true;
        		displacement += 5;
        	}    	
    	}
    	return smallestPos;
    }
}
