package application.model;

import javafx.scene.paint.Color;
import javafx.scene.shape.Polygon;

/**
 * Building is a Java class which contains information of each central building on campus.<br>
 * It stores information such as the name of the building, its x,y coordinate on the campus map, a boundary area around the building, and whether or not we can pass through the building directly.
 * 
 * @author Brent Delia (gis262), Nicholas Calzada (emy990), Samantha Ramos (alk208), Matthew Rodriguez (gjz898)
 * UTSA CS 3443 - Applications Final Project
 * Fall 2019
 */

public class Building {
	
	private String name;
	private double x;
	private double y;
	private Polygon boundary;
	private boolean canPass;
	
	/**
	 * Constructor method for the Building class
	 * @param name Name of the building as a String
	 * @param x The x coordinate of the building on the map as a double
	 * @param y The y coordinate of the building on the map as a double
	 * @param boundary A Polygon object which represents its boundary area
	 * @param boundary_x The x coordinate of the boundary on the map as a double
	 * @param boundary_y The y coordinate of the boundary on the map as a double
	 * @param canPass A boolean variable which denotes whether the algorithm allows a line to pass through the building directly
	 */
	
	public Building(String name, double x, double y, Polygon boundary, double boundary_x, double boundary_y, boolean canPass) {
		this.name = name;
		this.x = x;
		this.y = y;
		this.boundary = boundary;
		this.canPass = canPass;
		
		boundary.setLayoutX(boundary_x);
		boundary.setLayoutY(boundary_y);
		boundary.setFill(Color.TRANSPARENT);
		boundary.setStroke(Color.BLACK);
		boundary.setVisible(false);
	}
	
	/**
	 * Fetches the name of the Building object
	 * @return The name of the Building object
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * Sets the name of the Building object as a String
	 * @param name A String to assign on to the Building's name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Fetches the x coordinate of the Building object
	 * @return The x coordinate of the Building object
	 */
	public double getX() {
		return x;
	}

	/**
	 * Sets the x coordinate of the Building object as a double
	 * @param x A double to assign on to the Building's x coordinate on the map
	 */
	public void setX(double x) {
		this.x = x;
	}
	
	/**
	 * Fetches the y coordinate of the Building object
	 * @return The y coordinate of the Building object
	 */	
	public double getY() {
		return y;
	}

	/**
	 * Sets the y coordinate of the Building object as a double
	 * @param y A double to assign on to the Building's y coordinate on the map
	 */
	public void setY(double y) {
		this.y = y;
	}

	/**
	 * Fetches the Polygon boundary of the Building object
	 * @return The boundary of the Building object as a Polygon
	 */
	public Polygon getBoundary() {
		return boundary;
	}

	/**
	 * Sets the Polygon boundary of the Building object
	 * @param boundary A Polygon object to assign on to the Building's boundary
	 */
	public void setBoundary(Polygon boundary) {
		this.boundary = boundary;
	}
	
	/**
	 * Denotes whether we can pass through the Building object or not
	 * @return True = Can pass through the building<br>False = Otherwise
	 */
	public boolean canPass() {
		return canPass;
	}
	
	/**
	 * Sets whether or not we can pass through the Building object
	 * @param canPass A boolean variable to assign on to the Building's canPass flag
	 */
	public void setPass(boolean canPass) {
		this.canPass = canPass;
	}
	
	/**
	 * Method to visually show the boundary Polygon of the Building object
	 */
	public void showBoundary() {
		boundary.setVisible(true);
	}
	
	/**
	 * Method to visually hide the boundary Polygon of the Building object
	 */
	public void hideBoundary() {
		boundary.setVisible(false);
	}
}
