package application.controller;

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.Group;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.util.Duration;

import java.util.*;

import application.model.Building;
import application.model.Model;
import javafx.application.ConditionalFeature;
import javafx.application.Platform;
import javafx.geometry.Rectangle2D;
import javafx.stage.Screen;

/**
 * Controller is a Java class which connects our controls from our XML file to our program.<br>
 * It also stores our containers, controls, and menus found in our XML file to access and modify them freely.<br>
 * This class will also interact with our Model class to initiate our buildings list in order to store them within our ListView as well as starting up the search algorithm<br>
 * 
 * @author Brent Delia (gis262), Nicholas Calzada (emy990), Samantha Ramos (alk208), Matthew Rodriguez (gjz898)
 * UTSA CS 3443 - Applications Final Project
 * Fall 2019
 */

public class Controller {

	private Model model = new Model();

    @FXML
    private VBox root_vbox;
    @FXML
    private ListView<String> map_listview;
    @FXML
    private ScrollPane map_scrollpane;
    @FXML
    private Slider zoom_slider;
    @FXML
    private MenuButton map_pin;
    @FXML
    private MenuItem pin_info;
    @FXML
    private ToggleButton contrast_togglebutton;
    @FXML
    private Button size_togglebutton;
    @FXML
    private Button start_button;
    @FXML
    private Button end_button;
    @FXML
    private MenuButton start_pin;
    @FXML
    private MenuItem start_pin_info;
    @FXML
    private MenuButton end_pin;
    @FXML
    private MenuItem end_pin_info;
    @FXML
    private Button clear_search;
    @FXML
    private Pane mainPane;
    @FXML
    private Pane pathPane;
    
    private Building selectedBuilding = null;
    private Building startBuilding = null;
    private Building endBuilding   = null;
    
    public Group zoomGroup;

    /**
     * This method will load up our buildings/obstacles, hide our pins/buttons, set our zoom group up, and set our map scrollpane to be pannable and adjust its initial scroll location
     */
    @FXML
    public void initialize() {

    	// Begin instantiating and loading all the buildings
    	model.loadBuildings();

    	ObservableList<String> names = FXCollections.observableArrayList();
    	for(Building b : model.getBuildingsList()) {
    		names.add(b.getName());
    		pathPane.getChildren().add(b.getBoundary());
    		//b.showBoundary();
    	}
    	for(Building b : model.getObstacleList()) {
    		pathPane.getChildren().add(b.getBoundary());
    		//b.showBoundary();
    	}
        Collections.sort(names);
        map_listview.setItems(names);
        
        // Hide pins and buttons
        map_pin.setVisible(false);
        start_pin.setVisible(false);
        end_pin.setVisible(false);
        start_button.setVisible(false);
        end_button.setVisible(false);
        clear_search.setVisible(false);

        // Adjust our zoom slider settings
        zoom_slider.setMin(0.5);
        zoom_slider.setMax(1.5);
        zoom_slider.setValue(1.0);
        zoom_slider.valueProperty().addListener((o, oldVal, newVal) -> zoom((Double) newVal));

        // Wrap scroll content in a Group so ScrollPane re-computes scroll bars
        Group contentGroup = new Group();
        zoomGroup = new Group();
        contentGroup.getChildren().add(zoomGroup);
        zoomGroup.getChildren().add(map_scrollpane.getContent());
        map_scrollpane.setContent(contentGroup);

        // Add large UI styling and make full screen if we are on device
        if (Platform.isSupported(ConditionalFeature.INPUT_TOUCH)) {
            root_vbox.getStyleClass().add("touch-sizes");
            Screen screen = Screen.getPrimary();
            Rectangle2D bounds = screen.getVisualBounds();
            root_vbox.setPrefSize(bounds.getWidth(), bounds.getHeight());
        }

        // Adds mouse movement to the map scroll pane
        map_scrollpane.setOnMousePressed(event -> {
        	map_scrollpane.setPannable(true);
        });

        // Sets scroll position of the map scroll pane
        map_scrollpane.setVvalue(0.25);
        map_scrollpane.setHvalue(0.75);
    }

    /**
     * This method will read whatever Building name was clicked on, and traverse the map pane towards that Building's x,y coordinate.<br>
     * Depending on if a starting location was set, this will also show a "Set Start" or "Set Destination" button.
     */
    @FXML
    public void listClicked() {
    	// Get the name of the Building that was clicked on
        String item = map_listview.getSelectionModel().getSelectedItem();

        // If no item has been selected from the list of buildings
        // Or if the start building is equal to the item building name
        if(item == null || (startBuilding != null && item.equals(startBuilding.getName()))) {
        	return;
        }
        
        selectedBuilding = model.findBuilding(item);

        // Animation scroll to new position
        
        double mapWidth = zoomGroup.getBoundsInLocal().getWidth();
        double mapHeight = zoomGroup.getBoundsInLocal().getHeight();
        double scrollH = selectedBuilding.getX() / mapWidth;
        double scrollV = selectedBuilding.getY() / mapHeight;

        Timeline timeline = new Timeline();
        KeyValue kv1 = new KeyValue(map_scrollpane.hvalueProperty(), scrollH);
        KeyValue kv2 = new KeyValue(map_scrollpane.vvalueProperty(), scrollV);
        KeyFrame kf = new KeyFrame(Duration.millis(500), kv1, kv2);
        timeline.getKeyFrames().add(kf);
        timeline.play();

        // Move the pin and set its info
        double pinW = map_pin.getBoundsInLocal().getWidth();
        double pinH = map_pin.getBoundsInLocal().getHeight();

        map_pin.setLayoutX(selectedBuilding.getX() - (pinW / 2));
        map_pin.setLayoutY(selectedBuilding.getY() - (pinH));
        pin_info.setText("Building Info: \n" + item);
        map_pin.setVisible(true);
        
        // Move the start button to the pin location
        if(startBuilding == null) {
            start_button.setLayoutX(map_pin.getLayoutX()-10.0);
            start_button.setLayoutY(map_pin.getLayoutY()+70.0);
            start_button.setVisible(true);
        }
        // If we have a start node, that means we must show the end button instead
        else {
            end_button.setLayoutX(map_pin.getLayoutX()-30.0);
            end_button.setLayoutY(map_pin.getLayoutY()+70.0);
            end_button.setVisible(true);       	
        }
        
    }

    /**
     * This method sets up our starting pin node to wherever our searched node was, and shows it to the user
     */
    @FXML
    public void set_start() {
        startBuilding = selectedBuilding;
        
    	// Adjust visibility and location of start_pin to map_pin
    	clear_search.setVisible(true);
    	start_pin.setVisible(true);
    	start_pin.setLayoutX(map_pin.getLayoutX());
    	start_pin.setLayoutY(map_pin.getLayoutY());
    	start_pin_info.setText(pin_info.getText() + "\nThis is your start location.");

    	map_pin.setVisible(false);
    	start_button.setVisible(false);
    }
    
    /**
     * This method sets up our destination pin node to wherever our searched node was, and shows it to the user.<br>
     * Once called, this method also clears out any lines on screen and begins path finding.
     */
    @FXML
    public void set_end() {
    	endBuilding = selectedBuilding;
    	
    	// adjust visibility and location of end_pin to map_pin
    	end_pin.setVisible(true);
    	end_pin.setLayoutX(map_pin.getLayoutX());
    	end_pin.setLayoutY(map_pin.getLayoutY());
    	end_pin_info.setText(pin_info.getText() + "\nThis is your end location.");

    	map_pin.setVisible(false);
    	end_button.setVisible(false);

    	// clear out any lines if changing destinations
    	model.clearLines(pathPane);
    	// draw line path from start_pin coordinates to end_pin coordinates
    	model.pathfind(null, startBuilding, endBuilding, pathPane, null, 0);

    }
    
    /**
     * Clears out everything on the map pane. Lines, pin nodes, buttons, etc.
     */
    @FXML
    void clear_search() {
    	// Clear out all pins, map-related buttons, and the line path
    	end_pin.setVisible(false);
    	start_pin.setVisible(false);
    	clear_search.setVisible(false);
    	map_pin.setVisible(false);
    	start_button.setVisible(false);
    	end_button.setVisible(false);
    	
    	// Clear out all lines drawn, if any
    	model.clearLines(pathPane);
    	
    	// Nullify our start pin checks
    	startBuilding = null;
    	endBuilding = null;
    	selectedBuilding = null;
    }

	/**
	 * This method will adjust our zoom slider in, zooming our entire zoomGroup inwards
	 */
    @FXML
    public void zoomIn() {

        double sliderVal = zoom_slider.getValue();
        zoom_slider.setValue(sliderVal + 0.1);
    }

    /**
     * This method will adjust our zoom slider down, zooming our entire zoomGroup outwards
     */
    @FXML
    public void zoomOut() {

        double sliderVal = zoom_slider.getValue();
        zoom_slider.setValue(sliderVal + -0.1);
    }
    
	/**
	 * This method will zoom our map pane wherever our zoom slider is currently at
	 * @param scaleValue A decimal value to adjust our zoom value to
	 */
    public void zoom(double scaleValue) {

        double scrollH = map_scrollpane.getHvalue();
        double scrollV = map_scrollpane.getVvalue();
        zoomGroup.setScaleX(scaleValue);
        zoomGroup.setScaleY(scaleValue);
        map_scrollpane.setHvalue(scrollH);
        map_scrollpane.setVvalue(scrollV);
    }

    /**
     * Toggles our window theme to "Contrast" (See application.css for the specific settings to this theme)
     */
    @FXML
    public void stylingContrast() {

        if (contrast_togglebutton.isSelected() == true) {
            root_vbox.getStyleClass().add("contrast");
        } else {
           root_vbox.getStyleClass().remove("contrast");
        }
    }

}