package application;

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Group;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Line;
import javafx.util.Duration;

import java.util.*;
import java.util.Map.Entry;

import javafx.application.ConditionalFeature;
import javafx.application.Platform;
import javafx.geometry.Rectangle2D;
import javafx.stage.Screen;

public class Controller {

    @FXML
    private VBox root_vbox;
    @FXML
    private ListView<String> map_listview;
    @FXML
    private ScrollPane map_scrollpane;
    @FXML
    private Slider zoom_slider;
    @FXML
    private MenuButton map_pin;
    @FXML
    private MenuItem pin_info;
    @FXML
    private ToggleButton contrast_togglebutton;
    @FXML
    private Button size_togglebutton;
    @FXML
    private Button start_button;
    @FXML
    private Button end_button;
    @FXML
    private MenuButton start_pin;
    @FXML
    private MenuItem start_pin_info;
    @FXML
    private MenuButton end_pin;
    @FXML
    private MenuItem end_pin_info;
    @FXML
    private Button clear_search;
    @FXML
    private Line line_path;
    
    private boolean hasStart; //If he have a start pin on the map, to then show the "set end" button instead when searching the map
    
    private String startName;

    private final HashMap<String, ArrayList<Comparable<?>>> hm = new HashMap<>();
    Group zoomGroup;

    @FXML
    void initialize() {

        assert map_listview != null : "fx:id=\"map_listview\" was not injected: check your FXML file 'Map.fxml'.";
        assert root_vbox != null : "fx:id=\"root_vbox\" was not injected: check your FXML file 'Map.fxml'.";
        assert contrast_togglebutton != null : "fx:id=\"contrast_togglebutton\" was not injected: check your FXML file 'Map.fxml'.";
        assert size_togglebutton != null : "fx:id=\"size_togglebutton\" was not injected: check your FXML file 'Map.fxml'.";
        assert map_scrollpane != null : "fx:id=\"map_scrollpane\" was not injected: check your FXML file 'Map.fxml'.";
        assert map_pin != null : "fx:id=\"map_pin\" was not injected: check your FXML file 'Map.fxml'.";
        assert pin_info != null : "fx:id=\"pin_info\" was not injected: check your FXML file 'Map.fxml'.";
        assert zoom_slider != null : "fx:id=\"zoom_slider\" was not injected: check your FXML file 'Map.fxml'.";
        assert start_button != null : "fx:id=\"start_button\" was not injected: check your FXML file 'Map.fxml'.";

        hm.put("Activity Center", new ArrayList<>(Arrays.asList(600.0, 325.0)));
        hm.put("Applied Enginnering and Technology Building", new ArrayList<>(Arrays.asList(1180.0, 720.0)));
        hm.put("Arts Building", new ArrayList<>(Arrays.asList(1230.0, 555.0)));
        hm.put("Business Building", new ArrayList<>(Arrays.asList(1180.0, 385.0)));
        hm.put("Bosque Street Building", new ArrayList<>(Arrays.asList(940.0, 375.0)));
        hm.put("Business Services Annex", new ArrayList<>(Arrays.asList(320.0, 550.0)));
        hm.put("Biosciences Building", new ArrayList<>(Arrays.asList(1145.0, 650.0)));
        hm.put("Biotechnology Sciences and Engineering Building", new ArrayList<>(Arrays.asList(1210.0, 680.0)));
        //hm.put("Center for Archaeological Research", new ArrayList<>(Arrays.asList(260.0, 575.0)));
        hm.put("Convocation Center", new ArrayList<>(Arrays.asList(908.0, 610.0)));
        hm.put("Child Development Center", new ArrayList<>(Arrays.asList(430.0, 892.0)));
        hm.put("Central Receiving & Warehouse", new ArrayList<>(Arrays.asList(1425.0, 1438.0)));
        hm.put("Engineering Building", new ArrayList<>(Arrays.asList(1175.0, 625.0)));
        hm.put("Flawn Sciences Building", new ArrayList<>(Arrays.asList(1145.0, 575.0)));
        //hm.put("Facilities Services Building", new ArrayList<>(Arrays.asList(255.0, 650.0)));
        hm.put("Graduate School & Research Building", new ArrayList<>(Arrays.asList(995.0, 310.0)));
        hm.put("H-E-B Student Union", new ArrayList<>(Arrays.asList(1005.0, 555.0)));
        hm.put("John Peace Library", new ArrayList<>(Arrays.asList(1215.0, 430.0)));
        hm.put("Main Building", new ArrayList<>(Arrays.asList(1275.0, 425.0)));
        //hm.put("Margaret Batts Tobin Laboratories", new ArrayList<>(Arrays.asList(285.0, 420)));
        //hm.put("MEMS Lab", new ArrayList<>(Arrays.asList(390.0, 495.0)));
        hm.put("McKinney Humanities Building", new ArrayList<>(Arrays.asList(1090.0, 425.0)));
        hm.put("Multidisciplinary Studies Building", new ArrayList<>(Arrays.asList(1090.0, 505.0)));
        hm.put("North Paseo Building", new ArrayList<>(Arrays.asList(1050.0, 300.0)));
        //hm.put("Power & Dynamics Systems Lab", new ArrayList<>(Arrays.asList(1079.0, 1025.0)));
        //hm.put("Physical Education Building", new ArrayList<>(Arrays.asList(1079.0, 1025.0)));
        hm.put("Roadrunner Cafe", new ArrayList<>(Arrays.asList(670.0, 295.0)));
        hm.put("Recreation Wellness Center", new ArrayList<>(Arrays.asList(800.0, 680.0)));
        //hm.put("Sculpture & Ceramics Graduate Studio", new ArrayList<>(Arrays.asList(390.0, 545.0)));
        hm.put("Science and Engineering Building", new ArrayList<>(Arrays.asList(1270.0, 670.0)));
        //hm.put("Science and Engineering Lab", new ArrayList<>(Arrays.asList(410.0, 475.0)));
        //hm.put("Science Research Laboratories", new ArrayList<>(Arrays.asList(332.0, 467.0)));
        hm.put("Student Union", new ArrayList<>(Arrays.asList(1000.0, 470.0)));
        hm.put("Thermal Energy Plant", new ArrayList<>(Arrays.asList(930.0, 410.0)));

        
        ObservableList<String> names = FXCollections.observableArrayList();
        Set<Entry<String, ArrayList<Comparable<?>>>> set = hm.entrySet();
        Iterator<Entry<String, ArrayList<Comparable<?>>>> i = set.iterator();
        while (i.hasNext()) {
            Map.Entry<String, ArrayList<Comparable<?>>> me = i.next();
            names.add((String) me.getKey());
        }
        Collections.sort(names);

        map_listview.setItems(names);
        
        // Hide pins and buttons
        map_pin.setVisible(false);
        start_pin.setVisible(false);
        end_pin.setVisible(false);
        start_button.setVisible(false);
        end_button.setVisible(false);
        clear_search.setVisible(false);

        zoom_slider.setMin(0.5);
        zoom_slider.setMax(1.5);
        zoom_slider.setValue(1.0);
        zoom_slider.valueProperty().addListener((o, oldVal, newVal) -> zoom((Double) newVal));

        // Wrap scroll content in a Group so ScrollPane re-computes scroll bars
        Group contentGroup = new Group();
        zoomGroup = new Group();
        contentGroup.getChildren().add(zoomGroup);
        zoomGroup.getChildren().add(map_scrollpane.getContent());
        map_scrollpane.setContent(contentGroup);

        // Add large UI styling and make full screen if we are on device
        if (Platform.isSupported(ConditionalFeature.INPUT_TOUCH)) {
            //size_togglebutton.setSelected(true);
            root_vbox.getStyleClass().add("touch-sizes");
            Screen screen = Screen.getPrimary();
            Rectangle2D bounds = screen.getVisualBounds();
            root_vbox.setPrefSize(bounds.getWidth(), bounds.getHeight());
        }

        // Adds mouse movement to the map scroll pane
        map_scrollpane.setOnMousePressed(event -> {
        	map_scrollpane.setPannable(true);
        });

        // Sets scroll position of the map scroll pane
        map_scrollpane.setVvalue(0.15);
        map_scrollpane.setHvalue(0.70);
    }

    @FXML
    void listClicked(MouseEvent event) {
        String item = map_listview.getSelectionModel().getSelectedItem();

        // If no item has been selected from the list of buildings
        // Or if the start building is equal to the item building name
        if(item == null || item.equals(startName)) {
        	return;
        }
        
        List<Comparable<?>> list = hm.get(item);
        //List<Object> list = (List)hm.get(item);

        // animation scroll to new position
        double mapWidth = zoomGroup.getBoundsInLocal().getWidth();
        double mapHeight = zoomGroup.getBoundsInLocal().getHeight();
        double scrollH = (Double) list.get(0) / mapWidth;
        double scrollV = (Double) list.get(1) / mapHeight;

        final Timeline timeline = new Timeline();
        final KeyValue kv1 = new KeyValue(map_scrollpane.hvalueProperty(), scrollH);
        final KeyValue kv2 = new KeyValue(map_scrollpane.vvalueProperty(), scrollV);
        final KeyFrame kf = new KeyFrame(Duration.millis(500), kv1, kv2);
        timeline.getKeyFrames().add(kf);
        timeline.play();

        // move the pin and set its info
        double pinW = map_pin.getBoundsInLocal().getWidth();
        double pinH = map_pin.getBoundsInLocal().getHeight();
        map_pin.setLayoutX((Double) list.get(0) - (pinW / 2));
        map_pin.setLayoutY((Double) list.get(1) - (pinH));
        pin_info.setText("Building Info: \n" + item);
        map_pin.setVisible(true);
        
        // move the start button to the pin location
        if(!hasStart) {
            start_button.setLayoutX(map_pin.getLayoutX()-10.0);
            start_button.setLayoutY(map_pin.getLayoutY()+70.0);
            start_button.setVisible(true);
        }
        // if we have a start node, that means we must show the end button instead
        else {
            end_button.setLayoutX(map_pin.getLayoutX()-30.0);
            end_button.setLayoutY(map_pin.getLayoutY()+70.0);
            end_button.setVisible(true);       	
        }
        
    }
    
    @FXML
    void set_start() {
    	// adjust visibility and location of start_pin to map_pin
    	clear_search.setVisible(true);
    	start_pin.setVisible(true);
    	start_pin.setLayoutX(map_pin.getLayoutX());
    	start_pin.setLayoutY(map_pin.getLayoutY());
    	start_pin_info.setText(pin_info.getText() + "\nThis is your start location!");
    	
    	// now we have a start node
        hasStart = true;
        
        // set startName to the name of the building of the start pin to avoid having an end node with this name
        String info = pin_info.getText();
        startName = info.substring(info.indexOf(":") + 3);

    	map_pin.setVisible(false);
    	start_button.setVisible(false);
    }
    
    @FXML
    void set_end() {
    	// adjust visibility and location of end_pin to map_pin
    	end_pin.setVisible(true);
    	end_pin.setLayoutX(map_pin.getLayoutX());
    	end_pin.setLayoutY(map_pin.getLayoutY());
    	end_pin_info.setText(pin_info.getText() + "\nThis is your end location!");
    	
    	map_pin.setVisible(false);
    	end_button.setVisible(false);
    	
    	// draw line path from start_pin coordinates to end_pin coordinates
    	line_path.setVisible(true);
    	line_path.setStartX(start_pin.getLayoutX() + start_pin.getWidth()/2);
    	line_path.setStartY(start_pin.getLayoutY() + start_pin.getHeight());
    	line_path.setEndX(end_pin.getLayoutX() + end_pin.getWidth()/2);
    	line_path.setEndY(end_pin.getLayoutY() + end_pin.getHeight());
    }
    
    @FXML
    void clear_search() {
    	// clears out all pins, map-related buttons, and the line path
    	end_pin.setVisible(false);
    	start_pin.setVisible(false);
    	clear_search.setVisible(false);
    	line_path.setVisible(false);
    	map_pin.setVisible(false);
    	start_button.setVisible(false);
    	end_button.setVisible(false);
    	
    	// nullify our start pin checks
    	startName = "";
    	hasStart = false;
    }

    @FXML
    void zoomIn(ActionEvent event) {

        double sliderVal = zoom_slider.getValue();
        zoom_slider.setValue(sliderVal += 0.1);
    }

    @FXML
    void zoomOut(ActionEvent event) {

        double sliderVal = zoom_slider.getValue();
        zoom_slider.setValue(sliderVal + -0.1);
    }

    private void zoom(double scaleValue) {

        double scrollH = map_scrollpane.getHvalue();
        double scrollV = map_scrollpane.getVvalue();
        zoomGroup.setScaleX(scaleValue);
        zoomGroup.setScaleY(scaleValue);
        map_scrollpane.setHvalue(scrollH);
        map_scrollpane.setVvalue(scrollV);
    }

    @FXML
    void stylingContrast(ActionEvent event) {

        if (contrast_togglebutton.isSelected() == true) {
            root_vbox.getStyleClass().add("contrast");
        } else {
           root_vbox.getStyleClass().remove("contrast");
        }
    }

}