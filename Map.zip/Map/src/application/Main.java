package application;
	
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.fxml.FXMLLoader;

/**
 * Main sets up the FXML file and loads it on to the Scene for the user to view.
 * 
 * @author Brent Delia (gis262), Nicholas Calzada (emy990), Samantha Ramos (alk208), Matthew Rodriguez (gjz898)
 * UTSA CS 3443 - Applications Final Project
 * Fall 2019
 */

public class Main extends Application {
	@Override
	public void start(Stage primaryStage) throws Exception{
		Parent root = FXMLLoader.load(getClass().getResource("/application/view/Map.fxml"));
		primaryStage.setTitle("UTSA Pathfinder");
		primaryStage.setScene(new Scene(root, 800, 500));
		primaryStage.show();
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
