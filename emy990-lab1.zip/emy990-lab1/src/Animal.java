/**
 * Animal is a Java class containing an animal constructor, a toString method, getters, and setters.
 * This class contains a String for the Animal name, another string for the animal type
 * and a boolean indicating if the animal is a carnivore.
 * 
 * @author Nicholas Calzada (emy990)
 * UTSA CS 3443 - Lab 1
 * Fall 2019
 */
public class Animal {

	private String type;
	private String name;
	private boolean Carnivore;
	
	public Animal(String type, String name, boolean Carnivore)
	{
		this.type = type;
		this.name = name;
		this.Carnivore = Carnivore;
	}

	public String toString() {
		
		if(this.Carnivore == true) {
			 System.out.println(" >>  " + type + " - " + name + " (Carnivore)");
		}
		else {
			System.out.println(" >>  " + type + " - " + name + " (Vegetarian)");
		}
		return "";
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isCarnivore() {
		return Carnivore;
	}

	public void setCarnivore(boolean carnivore) {
		Carnivore = carnivore;
	}
	
}
