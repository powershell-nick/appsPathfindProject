/**
 * Zone is a Java class containing a zone constructor, a toString method, getters, setters,
 * and an addAnimal method.
 * This class contains a String for the zone name and a Animal array for the zones it holds.
 * 
 * @author Nicholas Calzada (emy990)
 * UTSA CS 3443 - Lab 1
 * Fall 2019
 */
public class Zone {

	private String name;
	private Animal animalArr[];
	
	public Zone(String name, int sizeOfArr)
	{
		this.name = name;
		this.animalArr = new Animal[sizeOfArr];
	}

	public String toString()
	{
		System.out.printf(this.name + " Zone : \n----------------\n");
		int i = 0;
		while((i != this.animalArr.length) && (this.animalArr[i] != null) )
		{
			Animal a = this.animalArr[i];
			a.toString();
			i++;
		}
		System.out.printf("\n");
		return "";
	}
	
	public void addAnimal(Animal newAnimal)
	{
		int i = 0;
		while(this.animalArr[i] != null)
		{
			i++;
		}
		this.animalArr[i] = newAnimal;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Animal[] getAnimalArr() {
		return animalArr;
	}

	public void setAnimalArr(Animal[] animalArr) {
		this.animalArr = animalArr;
	}
	
	
}
