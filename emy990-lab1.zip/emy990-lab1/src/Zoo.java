/**
 * Zoo is a Java class containing a zoo constructor a toString method and getters and setters.
 * This class contains a String for the zoo name and a Zone array for the zones it holds. 
 * 
 * @author Nicholas Calzada (emy990)
 * UTSA CS 3443 - Lab 1
 * Fall 2019
 */
public class Zoo {

	private String name;
	private Zone zoneArr[];
	
	public Zoo(String name, int sizeOfArr)
	{
		this.name = name;
		this.zoneArr = new Zone[sizeOfArr];
	}
	
	public String toString() 
	{
		System.out.printf("Welcome to the \"" + this.name + "\"! \n----------------------------------\n");
		int i = 0;
		while(this.zoneArr[i] != null)
		{
			Zone z = this.zoneArr[i];
			z.toString();
			i++;
		}
		return "";
	}
	
	public void addZone(Zone newZone)
	{
		int i = 0;
		while(this.zoneArr[i] != null)
		{
			i++;
		}
		this.zoneArr[i] = newZone;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Zone[] getZoneArr() {
		return zoneArr;
	}

	public void setZoneArr(Zone[] zoneArr) {
		this.zoneArr = zoneArr;
	}
	
}
